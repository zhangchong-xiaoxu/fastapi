<template>
    <div class="content">
      <!-- 顶部区域 -->
      <introParagraph></introParagraph>
      <!-- 默认问题 -->
      <defaultQuestion />
      <!-- 对话 -->
      <chatMessage></chatMessage>
      <inputArea></inputArea>
    </div>
    <!-- 底部输入框 -->
    
    <div style="height: 300px"></div>
  </template>
  
  <script setup lang="ts">
  import introParagraph from '@/page/component/introParagraph.vue';
  import defaultQuestion from "@/page/component/defaultQuestion.vue";
  import chatMessage from "@/page/component/chatMessage.vue";
  import inputArea from "@/page/component/inputArea.vue";
 

  </script>

  <style></style>
  