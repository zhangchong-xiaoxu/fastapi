<!-- src/page/TrainTicketQuery/TrainTicketQuery.vue -->
<template>
    <div>
      <van-nav-bar 
        title="火车票查询" 
        left-arrow 
        fixed 
        placeholder 
        @click-left="goBack" 
      />
      <div>
        <h2>火车票查询</h2>
        <form @submit.prevent="queryTrainTickets">
          <input v-model="departure" placeholder="出发地"/>
          <input v-model="destination" placeholder="目的地"/>
          <input type="date" v-model="date"/>
          <button type="submit">查询火车票</button>
        </form>
        <ul>
          <li v-for="ticket in tickets" :key="ticket.id">{{ ticket.train_no }} - {{ ticket.departure_time }}</li>
        </ul>
      </div>
    </div>
  </template>
  
  <script setup lang="ts">
  import { ref } from 'vue';
  import axios from 'axios';
  import { BASE_API_URL } from '@/api/request'; // 假设路径正确
  
  const departure = ref('');
  const destination = ref('');
  const date = ref('');
  const tickets = ref([]);
  
  async function queryTrainTickets() {
    try {
      const response = await axios.post(`${BASE_API_URL}/api/trainTickets`, {
        departure: departure.value,
        destination: destination.value,
        date: date.value
      });
      tickets.value = response.data;
    } catch (error) {
      console.error("查询火车票时出错:", error);
    }
  }
  
  function goBack() {
    window.history.length > 1 ? window.history.back() : window.location.href = '/';
  }
  </script>
  
  <style scoped>
  /* 根据需要添加样式 */
  </style>