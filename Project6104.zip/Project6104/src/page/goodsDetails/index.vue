<template>
    <van-nav-bar title="详情页" left-arrow fixed placeholder />
    <img class="cover-image" src="https://se-feed-bucket.cdn.bcebos.com/map_uigc_subway_scence/3173316d0cc29cd7f65ea9a7ca876700-s0.jpg" alt="">
    <div class="price-and-title">
        <p class="goods-price">199/人</p>
        <p class="goods-title">标题标题标题标题</p>
    </div>
    <div class="goods-details">
        <p class="goods-describe">产品特色</p>
        <img src="https://bj.bcebos.com/bjh-pixel/17131381640484594405_1_ainote_new.jpg" alt="">
        <img src="https://qcloud.dpfile.com/pc/j8_lmADXRQlCd2yyLcHcJfMM108IxKP79aJQHGf5YiVNOjhI_EJzeBbPPYSwXW1h.jpg" alt="">
        <img src="https://qcloud.dpfile.com/pc/IjrMl2d60y6TdieJiV0xCht9et3BCLVHccB4ljWhurHGoXdRp1aisJsoP331ir-c.jpg" alt="">
    </div>
    <div class="submit">
        <van-button type="primary" block>立即报名</van-button>
    </div>
    <div style="height: 100px"></div>
    </template>
    
    <script setup lang="ts">
    
    </script>
    
    <style scoped lang="less">
.cover-image {
  width: 100%;
  max-height: 300px;
  object-fit: cover;
}
.price-and-title {
  background-color: #ffffff;
  margin: 10px;
  padding: 10px;
  border-radius: 10px;
  .goods-price {
    font-size: 22px;
    color: red;
    padding-bottom: 10px;
  }
  .goods-title {
    font-size: 19px;
  }
}
.goods-details {
  background-color: #ffffff;
  margin: 10px;
  border-radius: 10px;
  padding: 10px;
  .goods-describe {
    padding-bottom: 10px;
    font-weight: bold;
  }
  img {
    width: 100%;
  }
}
.submit {
  background-color: #ffffff;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 10px 20px 20px 20px;
}
</style>
