<template>
    <div class="input-container">
      <div class="data-query">
        <van-button size="small" type="default">查询火车票</van-button>
        <van-button size="small" type="default">查询天气</van-button>
        <van-button size="small" type="default" @click="goToComplaintPage">一键投诉</van-button> <!-- 添加@click事件处理器 -->
      </div>
  
      <div class="input-box-area">
        <van-field 
          v-model="inputValue"
          class="input-content" 
          type="textarea" 
          placeholder="请输入询问内容"
          :border="false"
          @input="handleInput"
        />
        <van-button class="send-button" size="small" type="default" @click="handleSend">发送</van-button>
      </div>
    </div>
  </template>
  
  <script setup lang="ts">
  import { ref } from "vue";
  
  const inputValue = ref("");
  const validKeywords = ["车票", "天气", "投诉"];
  
  function handleInput() {
    // 这里可以添加逻辑来自动检查或修正输入值
  }
  
  function handleSend() {
    if (validKeywords.includes(inputValue.value)) {
      if (inputValue.value === "投诉") {
        goToComplaintPage();
      } else {
        alert(`你选择了: ${inputValue.value}`); // 或者执行其他操作
      }
    } else {
      alert("请输入有效的关键词：车票、天气或投诉");
    }
  }
  
  function goToComplaintPage() {
    window.location.href = "http://127.0.0.1:6104/agent#/complaintPage"; // 定义跳转函数
  }
  </script>
  
  <style scoped lang="less">
  /* 样式部分保持不变 */
  .input-container {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
  
    padding: 10px;
    background-color: #ffffff;
    box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
  
    .data-query {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
  
      .van-button {
        margin-left: 10px;
        margin-bottom: 3px;
        opacity: 1;
      }
    }
  
    .input-box-area {
      display: flex;
      align-items: center;
      padding: 10px;
      background-color: #f8f9fd;
      border-radius: 10px;
  
      .input-content {
        flex: 1;
        padding: 6px;
        border-radius: 10px;
        background-color: #ffffff;
        font-size: 8px; // 调整字体大小
        color: #333333;
        max-height: 20px; // 设置最大高度
        min-height: 10px; // 设置最小高度
        line-height: 1.2; // 调整行高
      }
  
      .send-button {
        border: none;
        font-size: 15px;
        color: #3a71e8;
        font-weight: bold;
        margin-left: 10px;
      }
    }
  }
  </style>