// src/router/index.js
import { createWebHashHistory, createRouter } from "vue-router";

const routes = [
  {
    // 聊天界面
    path: "/",
    name: "home",
    component: () => import("@/page/home/home.vue"),
  },
  {
    // 商品详情页
    path: "/goodsDetails",
    name: "goodsDetails",
    component: () => import("@/page/goodsDetails/index.vue"),
  },
  {
    // 火车票查询页面
    path: "/TrainTicketQuery",
    name: "TrainTicketQuery",
    component: () => import("@/page/TrainTicketQuery/TrainTicketQuery.vue")
  },
  {
    // 投诉页面
    path: "/complaintPage",
    name: "complaintPage",
    component: () => import("@/page/complaintPage/index.vue"),
  },
];

// 创建路由实例
const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;