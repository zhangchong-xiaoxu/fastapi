export const cityData=[
    {
        text:"杭州市",
        value:"hangzhou",
        children:[
            {text:"上城区",value:"shangcheng"},
            {text:"拱墅区",value:"gongshu"},
            {text:"西湖区",value:"xihu"},
            {text:"滨江区",value:"bingjiang"},
            {text:"萧山区",value:"xiaoshan"},
            {text:"余杭区",value:"yuhang"},
            {text:"富阳区",value:"fuyang"},
            {text:"临平区",value:"linpin"},
            {text:"钱塘区",value:"qiantan"},
            {text:"桐庐县",value:"tonglu"}, 
            {text:"淳安县",value:"chunan"},
            {text:"建德市",value:"jiande"}
        ]
    },


]

      