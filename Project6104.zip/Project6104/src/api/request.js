import { showToast } from "vant";

const requestUrl = "http://127.0.0.1:666"; // 注意端口号应与实际服务匹配

// fetch请求
const fetchApi = async (url, method = "POST", body, resType = "stream") => {
    const headers = {};
    if (method === "POST" && typeof body === 'object') {
        headers["Content-Type"] = "application/json";
    }
    const options = {
        method,
        headers,
    };
    if (method === "POST") {
        options.body = JSON.stringify(body);
    }

    const response = await fetch(url, options);

    if (response.ok && resType !== "stream") {
        return await response.json();
    }

    if (!response.ok) {
        const errorData = await response.json();
        const status = response.status;
        switch (status) {
            case 404:
                console.error("404 Not Found");
                break;
            case 500:
            case 501:
            case 502:
                console.error("Server error occurred");
                showToast({ message: "An unexpected error occurred.", duration: 1000 });
                break;
            case 400:
                console.error("Bad Request");
                break;
            case 422:
                console.error("Unprocessable Entity");
                showToast({ message: errorData.msg, duration: 1000 });
                break;
            default:
                console.error(`Error: ${status}`);
        }
        throw errorData;
    }

    if (response.ok && resType === "stream") {
        const reader = response.body.getReader();
        const decoder = new TextDecoder("utf-8");
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            const decodedString = decoder.decode(value, { stream: true });
            // 进一步处理decodedString...
        }
    }
};

// 发送消息
export const chatMessageApi = (data) => {
    return fetchApi(`${requestUrl}/chatMessage`, "POST", data);
};

// 查询火车票
export const queryTrainTickets = (data) => {
    return fetchApi(`${requestUrl}/queryTrainTickets`, "POST", data);
};

// 查询天气
export const queryWeather = (data) => {
    return fetchApi(`${requestUrl}/queryWeather?city=${data.city}`, "GET");
};

// 搜索商品
export const searchGoods = (data) => {
    return fetchApi(`${requestUrl}/searchGoods`, "POST", data);
};

// 查看商品详情
export const goodsDetails = (data) => {
    return fetchApi(`${requestUrl}/goodsDetails`, "POST", data);
};

// 图片上传
export const uploadFile = (data) => {
    return fetchApi(`${requestUrl}/uploadFile`, "POST", data);
};

// 提交投诉
export const addComplaint = (data) => {
    return fetchApi(`${requestUrl}/addComplaint`, "POST", data);
};