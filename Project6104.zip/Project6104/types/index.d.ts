import { ServerSearchGoodsType } from "@/types";

export type TextContent ={type:'text',text:string}


export type chatMessageType={
    role:"user" |"assistant"
    content:string | Array<TextContent  >
    toolData?:any;//
    type?:"function";
    functionName?:string;
    progress ?:boolean;
    searchGoodsData ?: ServerSearchGoodsType};
    